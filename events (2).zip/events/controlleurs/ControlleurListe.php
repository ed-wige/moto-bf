<?php
// public function getAll(){
//     if ($statu=='vendu') {
//         echo('hidden');
//     }
// }
// $events=new EventManager();
// $getliste=$events->get();
// $nombre=$events->getNombre();
// if(isset($_GET["id"])){
//     $motos->supprimer($_GET["id"]);
// }

// <?php
    include('EventManager.class.php');
    require_once ('../vues/liste.php')

    $event=new Event();
    function val($ct){
        if($ct!=""){
            echo $ct;
        }
    }
?>
// if(isset($_GET["marque"])){
//     $motoliste=$motos->getMarque($_GET["marque"]);
//     $nombre=$motos->getNombre($_GET["marque"]);
// }
$contenu="../vues/liste.vue.php";
require("../vues/app.vue.php");
?>
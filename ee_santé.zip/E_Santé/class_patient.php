<?php


class Patient{

private $bd;

function __construct(){

    try{
        $this->bd=new PDO('mysql:host=localhost; dbname=e_santé', 'root', '');
        
    }
    catch (PDOException $e){
        echo 'Erreur: '.$e->getMessage();
    }

    
}


public function enregistrer($nom, $prenom, $birthday, $residence, $genre,  $profession, $telephone, $groupesanguin, $electrophorèse, 
    $maladiegentique, $allergie, $serologie, $lastvisit, $mdcname, $mdcemail, $mdctel, $nomp, $prenomp, $telephonep, $professionp ){
    $insert=$this->bd->prepare('INSERT INTO patient(nom, prenom, date_de_naissance, lieu_de_residence, genre, profession, telephone, groupe_sanguin,
    electrophorese, maladie_hereditaire, allergie, serologie, date_de_la_derniere_visite, medecin_traitant, email_du_medecin, telephone_du_medecin,
    nom_accompagnant, prenom_accompagnat, telaccompagnant, profession_accompagnant) VALUES (:nom,:prenom,:date_de_naissance,:lieu_de_residence,
    :genre,:profession,:telephone,:groupe_sanguin,:electrophorese,:maladie_hereditaire,:allergie,:serologie,:date_de_la_derniere_visite
    ,:medecin_traitant,:email_du_medecin,:telephone_du_medecin,:nom_accompagnant,:prenom_accompagnat,:telaccompagnant,:profession_accompagnant)');

    $insert->execute(array(
        "nom"=> $nom,
        "prenom"=> $prenom,
        "date_de_naissance"=> $birthday,
        "lieu_de_residence"=>$residence,
        "genre" =>$genre,
        "profession" =>$profession,
        "telephone" =>$telephone,
        "groupe_sanguin" =>$groupesanguin,
        "electrophorese" =>$electrophorèse,
        "maladie_hereditaire" =>$maladiegentique,
        "allergie" =>$allergie, 
        "serologie" =>$serologie, 
        "date_de_la_derniere_visite" =>$lastvisit, 
        "medecin_traitant" =>$mdcname, 
        "email_du_medecin" =>$mdcemail, 
        "telephone_du_medecin" =>$mdctel, 
        "nom_accompagnant" =>$nomp, 
        "prenom_accompagnat" =>$prenomp, 
        "telaccompagnant" =>$telephonep, 
        "profession_accompagnant" =>$professionp

    ));
}

public function maj($id, $nom, $prenom, $birthday, $residence, $genre,  $profession, $telephone, $groupesanguin, $electrophorèse, 
$maladiegentique, $allergie, $serologie, $lastvisit, $mdcname, $mdcemail, $mdctel, $nomp, $prenomp, $telephonep, $professionp){

    $maj=$this->bd->prepare('UPDATE patient SET nom=:noms, prenom=:prenoms, date_de_naissance=:date_de_naissances,
    lieu_de_residence=:lieu_de_residences, genre=:genres, profession=:professions, telephone=:telephones, groupe_sanguin=:groupe_sanguins,
    electrophorese=:electrophoreses, maladie_hereditaire=:maladie_hereditaires, allergie=:allergies, serologie=:serologies,
    date_de_la_derniere_visite=:date_de_la_derniere_visites, medecin_traitant=:medecin_traitants, email_du_medecin=:email_du_medecins,
    telephone_du_medecin=:telephone_du_medecins, nom_accompagnant=:nom_accompagnants, prenom_accompagnat=:prenom_accompagnats, telaccompagnant=:telaccompagnants,
    profession_accompagnant=:profession_accompagnants WHERE id=:id');

    $maj->execute(array(

        "noms"=> $nom,
        "prenoms"=> $prenom,
        "date_de_naissances"=> $birthday,
        "lieu_de_residences"=>$residence,
        "genres" =>$genre,
        "professions" =>$profession,
        "telephones" =>$telephone,
        "groupe_sanguins" =>$groupesanguin,
        "electrophoreses" =>$electrophorèse,
        "maladie_hereditaires" =>$maladiegentique,
        "allergies" =>$allergie, 
        "serologies" =>$serologie, 
        "date_de_la_derniere_visites" =>$lastvisit, 
        "medecin_traitants" =>$mdcname, 
        "email_du_medecins" =>$mdcemail, 
        "telephone_du_medecins" =>$mdctel, 
        "nom_accompagnants" =>$nomp, 
        "prenom_accompagnats" =>$prenomp, 
        "telaccompagnants" =>$telephonep, 
        "profession_accompagnants" =>$professionp,
        "id"=>$id

    ));

}

public function supprimer($id){
    $supr=$this->bd->prepare("DELETE FROM patient WHERE id=:id");
    $supr->execute(array(
        "id"=>$id
    ));
}

public function getAll(){
    $patients=$this->bd->query("SELECT * FROM patient");
    return $patients->fetchAll();
}

function get($id){
    $patient=$this->bd->prepare("SELECT * FROM patient WHERE id=:id");
    $patient->execute(array(
        "id"=>$id
    ));
    return $patient->fetch();
}

}
<div class="card-footer text-muted">
           <p> © 2020 Copyright: Simplon.co Burkina Faso </p>
</div>
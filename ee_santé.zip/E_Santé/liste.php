<!Doctype html>
<html>
  <header>
  <meta charset='utf-8'>
  <title></title>
  <link rel="stylesheet" href="bootstrap4/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">

<?php
    include('class_patient.php');

    $patient=new Patient();
    function val($ct){
        if($ct!=""){
            echo $ct;
        }
    }
?>
  </header>
  <body>
  <div class="card text-center">
        <?php
            require('header.php');
        ?>
    
        <div class="card-body">
        <h2>Liste des patients</h2>
<?php
      if(isset($_GET['rep']))
      {
        echo '<h5>'.$_GET['rep'].'</h5>';
      }
?>
    
    <table class="table table-hover">
    <thead>
    <tr>
      <th scope="col">Supprimer</th>
      <th scope="col">Nom</th>
      <th scope="col">Prenom</th>
      <th scope="col">Contact</th>
      <th scope="col">Allergie</th>
      <th scope="col">Serologie</th>
      <th scope="col">Details</th>
    </tr>
  </thead>
  <tbody>
  <?php
  foreach ($patient->getAll() as $patient) {
  ?>
    <tr>
        <td><a href="supprimer.php?id=<?php echo $patient['id'];?>" class="text-danger">&#10060 </a></td>
        <td><?php echo $patient['nom'];?></td>
        <td><?php echo $patient['prenom'];?></td>
        <td><?php echo $patient['telephone'];?></td>
        <td><?php echo $patient['allergie'];?></td>
        <td><?php echo $patient['serologie'];?></td>
        <td><a href="detailsanou.php?id=<?php echo $patient['id'];?>">&#9998</a></td>
    </tr>
    <?php
    }
    ?>
  </tbody>
  </table>
  </div>
   
        <?php
            require('footer.php')
        ?>
    </div> 
  </body>
</html>
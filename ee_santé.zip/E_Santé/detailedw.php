<!Doctype html>
<html>
  <header>
  <meta charset='utf-8'>
  <title></title>
  <link rel="stylesheet" href="bootstrap4/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">

<?php
    include('class_patient.php');
    $patient_ctrl= new Patient();
    if(isset($_GET['id']))
{
    $id=$_GET['id'];
    $valuer=$patient_ctrl->get((int)$id);
    //echo $id;
}


    $patient=new Patient();
    function val($ct){
        if($ct!=""){
            echo $ct;
        }
    }
?>
 </header>
  <body>

  <h4 >Detail du patient </h4>

<div id='formulaire_bircof'>
<td><a href="detail.php?id=<?php echo $patient['Id'];?>">&#9998</a></td>

   
            <label for="">Nom:</label> <span> <?= $valuer->getNom()?> </span> <br>
            <label for="">Prenom:</label> <span><?= $valuer->getPrenom()?></span> <br>
            <label for="">Date de naissance:</label><span> <?= $valuer->getDate_de_naissance()?> </span>  <br>
            <label for="">Lieu de Résidence:</label> <span> <?= $valuer->getLieu_de_Résidence()?> </span>  <br>
            <label for="">Genre:</label><span> <?= $valuer->getGenre()?> </span>  <br>
            <label for="">Profession:</label><span> <?= $valuer->getProfession()?> </span>  <br>
            <label for="">Téléphone:</label><span> <?= $valuer->getTéléphone()?> </span>  <br>
            <label for="">Groupe Sanguin:</label><span> <?= $valuer->getGroupe_Sanguin()?> </span>  <br>
            <label for="">electrophorèse:</label><span> <?= $valuer->getelectrophorèse()?> </span>  <br>
            <label for="">Maladie Génétique:</label> <span> <?= $valuer->getMaladie_Héréditaire()?> </span> <br>
            <label for="">Allergies:</label> <span> <?= $valuer->getAllergies()?> </span> <br>
            <label for="">Sérologie:</label> <span> <?= $valuer->getSérologie()?> </span> <br>
            <label for="">Date de la dernière visite:</label> <span> <?= $valuer->getDate_de_la_dernière_visite()?> </span> <br>
            <label for="">Médecin traitant:</label> <span> <?= $valuer->getMédecin_traitant()?> </span> <br>
            <label for="">Email du médecin:</label> <span> <?= $valuer->getEmail_du_médecin()?> </span> <br>
            <label for="">Téléphone du médecin:</label> <span> <?= $valuer->getTéléphone_du_médecin()?> </span> <br>
            <label for="">Nom:</label> <span> <?= $valuer->getNom()?> </span> <br>
            <label for="">Prenom:</label> <span><?= $valuer->getPrenom()?></span> <br>
            <label for="">Profession:</label><span> <?= $valuer->getProfession()?> </span>  <br>
            <label for="">Téléphone:</label><span> <?= $valuer->getTéléphone()?> </span>  <br>

                        <div class='button'>
                            <a href="liste.php"> <button class="btn btn-outline-danger" id="btn-ajout"> Retour </button></a>
                        </div>
                        <?php
            require('footer.php')
        ?>
    </div>
    <?php
    header('liste.php');
    ?> 
  </body>
</html>

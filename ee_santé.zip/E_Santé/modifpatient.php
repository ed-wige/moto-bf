<?php 
include('class_patient.php');

$patient=new Patient();
if (isset($_POST)) {
    $patient->maj(
        $_GET['id'],
        $_POST['nom'],
        $_POST['prenom'],
        $_POST['date'],
        $_POST['residence'],
        $_POST['genre'],
        $_POST['profession'],
        $_POST['telephone'],


//antecedant

        $_POST['gs'],
        $_POST['elect'],
        $_POST['maladie'],
        $_POST['allergie'],
        $_POST['serologie'],


//medecin traitant

        $_POST['datevisit'],
        $_POST['mdcname'],
        $_POST['mdcemail'],
        $_POST['mdctel'],


//personne à prevenir en cas de besoin

        $_POST['nomp'],
        $_POST['prenomp'],
        $_POST['telp'],
        $_POST['professionp']

);
    header('liste.php?rep=Patient mis a jour avec succes');
}
?>
<?php

include('class_patient.php');

$patient=new Patient();
if (isset($_GET['id'])) {
    $patient->supprimer($_GET['id']);
    header('liste.php?rep=Patient supprimer avec succes'); 
}
?>
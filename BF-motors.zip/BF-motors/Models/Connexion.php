<?php


  $this->bd=new PDO('mysql:host=localhost; dbname=bf-motors', 'root', '');
  
catch (PDOException $e){
  echo 'Erreur: '.$e->getMessage();
}



  
   
  

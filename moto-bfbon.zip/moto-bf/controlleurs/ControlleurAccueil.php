<?php
class Controlleur{
$motoManager=new MotoManager();
$authen=new Athen();
}